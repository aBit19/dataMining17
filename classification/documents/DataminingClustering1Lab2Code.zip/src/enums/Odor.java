package enums;

public enum Odor {
	almond,
	anise,
	creosote,
	fishy,
	foul,
	musty,
	none,
	pungent,
	spicy,
}
