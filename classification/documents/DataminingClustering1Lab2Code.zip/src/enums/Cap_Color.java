package enums;

public enum Cap_Color {
	brown,
	buff,
	cinnamon,
	gray,
	green,
	pink,
	purple,
	red,
	white,
	yellow,
}
