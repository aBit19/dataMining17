package enums;

public enum Gill_Color {
	black,
	brown,
	buff,
	chocolate,
	gray,
	green,
	orange,
	pink,
	purple,
	red,
	white,
	yellow,
}
